const multer = require('multer');

var diskstorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, './public/uploads');
  },
  filename: (req, file, cb) => {
    cb(null, file.originalname+"-"+Date.now());
  }
});

const storage = multer({ storage:diskstorage}).single('avatar');


module.exports = storage;